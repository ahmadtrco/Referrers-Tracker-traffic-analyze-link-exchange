<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

	include('../config.php');
	include($full_path.'functions.php');
	doLogout($_REQUEST["logout"]);
	if (!userLogged()) 
	{
		exit;    
	}
	$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
	@mysql_select_db($tgdbName, $tgdb);
	
	$config = getConfig();
	include($full_path.'admin/header.php');
	
	$approved_result = mysql_query("select * from tg_ref_approved where url = '".$_REQUEST["url"]."'");

	if (mysql_num_rows($approved_result) == 0) 
	{	
		?>
		<center><a href="edit.php?url=<? echo $_REQUEST["url"];?>&action=approve" title="Approve <? echo $_REQUEST["url"];?>"><img src="images/checkmark.gif" width="14" height="11" border="0"></a>&nbsp;&nbsp;
		<?
	}
	$short_url = str_replace("www.", "", $_REQUEST["url"]);
	?>
	<a href="index.php?url=<? echo $short_url;?>&action=ban" onClick="return confirm('Are you sure you want to ban <? echo $_REQUEST["url"];?>?');" title="Ban <? echo $_REQUEST["url"];?>"><img src="images/icon-delete.gif" width="12" height="17" border="0"></a></center><br>
  <table width="100%"  border="1" cellspacing="0" cellpadding="0">
    <tr bgcolor="#CCCCCC">
      <td><div align="left"><b>Full URL</b></div></td>
      <td><div align="left"><b>Hits In</b></div></td>
    </tr>
<?
$ref_result = mysql_query("select full_url, count(*) as full_count from tg_ref_hits where url = '".$_REQUEST["url"]."' group by full_url order by full_count desc");
$count = 1;
while ($ref_row = mysql_fetch_array($ref_result))
{
	if ($count & 1)
	{
		echo "<tr bgcolor='#FFFFFF'>";
	}
	else
	{
		echo "<tr bgcolor='#EFEFEF'>";
	}
	?>
	<td><div align="left"><a href="<? echo $ref_row['full_url'];?>" target="_blank"><? echo $ref_row['full_url'];?></a></div></td>
	<td><div align="left"><? echo $ref_row['full_count'];?></div></td>
    </tr>
<?
$count++;
}
?>
  </table>
<?
	include($full_path.'admin/footer.php');
?>
