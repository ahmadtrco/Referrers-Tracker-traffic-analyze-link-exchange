<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

include('../config.php');
include($full_path.'functions.php');
doLogout($_REQUEST["logout"]);
if (!userLogged()) 
{
	exit;    
}
$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
@mysql_select_db($tgdbName, $tgdb);

$config = getConfig();
include($full_path.'admin/header.php');
	
// Approve
if ($_REQUEST["action"] == "approve")
{
	$current_datetime = date("Y-m-d H:i:s");
	$approve_check = mysql_query("select 'X' from tg_ref_approved where url = '".$_REQUEST["url"]."'");
	if (mysql_num_rows($approve_check) == 0) 
	{
		$approve_result = mysql_query("insert into tg_ref_approved (url, approval_date) values ('".$_REQUEST["url"]."', '".$current_datetime."')");
	}
}		
	
// Get data
$select_sql = "select * from tg_ref_approved where url = '".$_REQUEST["url"]."'";
$select_result = mysql_query($select_sql) or die("Error in select query");
$select_row = mysql_fetch_array($select_result);
$alias = $select_row["alias"];
$forward = $select_row["forward"];
?>
<form name="form2" method="post" enctype="multipart/form-data" action="index.php?action=edit&url=<? echo $_REQUEST["url"]; ?>">
  <table width="400" border="1" cellspacing="0" cellpadding="0">
    <tr bgcolor="#CCCCCC">
      <td colspan="2"><div align="center" class="style5"><br><? echo $_REQUEST["url"]; ?><br><br></div></td>
    </tr>
	<tr>
		<td align="right">Alias:</td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="alias" type="text" value="<? echo $alias; ?>" size="45"></td>
	</tr>
	<tr>
		<td align="right">Forward:</td>
		<td>http://<input name="forward" type="text" value="<? echo $forward; ?>" size="45"></td>
	</tr>
	<tr>
		<td colspan="2"><div align="right" class="style5"><input name="Save" type="submit" id="Save" value="Save"></div></td>
	</tr>
  </table>
</form>
<?
	include($full_path.'admin/footer.php');
?>
