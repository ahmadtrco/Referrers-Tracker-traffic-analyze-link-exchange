<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */
?>
<br>
<? 
	if ($adult == "YES")
	{
		?><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img alt="free referrers php scripts" src="images/hazratsultanbahu-icon.png" width="40" height="40" border="0"></a><?
	}
    else
	{
		?><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img alt="free referrers php scripts" src="images/hazratsultanbahu-icon.png" width="40" height="40" border="0"></a><?
	}
?>
<p>Copyright 2018<br>

<? 
	if ($adult == "YES")
	{
		?><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank">free referrers php scripts</a><?
	}
    else
	{
		?><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank">free referrers php scripts</a><?
	}
?>
<br>Version 1.1</p>
</div>
</body>
</html>
