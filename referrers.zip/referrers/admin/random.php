<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

	include('../config.php');
	include('../functions.php');
	doLogout($_REQUEST["logout"]);
	if (!userLogged()) 
	{
		exit;    
	}
	$tgdb = mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
	mysql_select_db($tgdbName, $tgdb);
	
	// Save
	if ($_REQUEST["action"] == "saverandom")
	{
		echo "insert into tg_random (title, url) values ('".$_REQUEST["title"]."', '".$_REQUEST["url"]."'";
		$insert_result = mysql_query("insert into tg_random (title, url) values ('".$_REQUEST["title"]."', '".$_REQUEST["url"]."'");
		echo "SAVED: ".$title." (".$url.")";
	}
	
?>
<form name="settingsform" method="post" enctype="multipart/form-data" action="random.php?action=saverandom">
  <table width="600" border="1" cellspacing="0" cellpadding="3">
    <tr bgcolor="#CCCCCC">
      <td colspan="2"><div align="center" class="style5"><br>RANDOM<br><br></div></td>
    </tr>
	<tr>
		<td align="right"><b>Title:</b></td>
		<td align="left"><input name="title" type="text" value="<? echo $title; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>URL:</b><br>(example: www.site.com)</td>
		<td align="left">http://<input name="url" type="text" value="<? echo $url; ?>" size="50"></td>
	</tr>						
	<tr>
		<td colspan="2"><div align="right" class="style5"><input name="Save" type="submit" id="Save" value="Save"></div></td>
	</tr>
  </table>
</form>
<?
	include('footer.php');
?>
