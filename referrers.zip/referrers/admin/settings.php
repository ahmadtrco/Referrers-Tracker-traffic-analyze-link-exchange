<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

	include('../config.php');
	include($full_path.'functions.php');
	doLogout($_REQUEST["logout"]);
	if (!userLogged()) 
	{
		exit;    
	}
	$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
	@mysql_select_db($tgdbName, $tgdb);
	
	$config = getConfig();
	include($full_path.'admin/header.php');
	
	// Get data
	$select_sql = "select * from tg_ref_config where config_id = 1";
	$select_result = mysql_query($select_sql) or die("Error in select query");
	$select_row = mysql_fetch_array($select_result);
	$tracking_days = $select_row["tracking_days"];
	$short_num_referrers = $select_row["short_num_referrers"];
	$short_num_columns = $select_row["short_num_columns"];
	$short_align_1 = $select_row["short_align_1"];
	$short_align_2 = $select_row["short_align_2"];
	$short_align_3 = $select_row["short_align_3"];
	$short_align_4 = $select_row["short_align_4"];
	$short_align_5 = $select_row["short_align_5"];
	$short_css = $select_row["short_css"];
	$random_num_referrers = $select_row["random_num_referrers"];
	$random_num_columns = $select_row["random_num_columns"];
	$random_align_1 = $select_row["random_align_1"];
	$random_align_2 = $select_row["random_align_2"];
	$random_align_3 = $select_row["random_align_3"];
	$random_align_4 = $select_row["random_align_4"];
	$random_align_5 = $select_row["random_align_5"];
	$random_css = $select_row["random_css"];	
	$full_per_page = $select_row["full_per_page"];
	$full_num_columns = $select_row["full_num_columns"];
	$full_align_1 = $select_row["full_align_1"];
	$full_align_2 = $select_row["full_align_2"];
	$full_align_3 = $select_row["full_align_3"];
	$full_align_4 = $select_row["full_align_4"];
	$full_align_5 = $select_row["full_align_5"];
	$full_css = $select_row["full_css"];
	$max_length = $select_row["max_length"];
	$min_hits = $select_row["min_hits"];

?>
<form name="settingsform" method="post" enctype="multipart/form-data" action="index.php?action=savesettings">
  <table width="600" cellspacing="0" cellpadding="3">
    <tr bgcolor="#CCCCCC">
      <td colspan="2"><div align="center" class="style5"><br><b>SETTINGS</b><br><br></div></td>
    </tr>
	<tr>
		<td align="right"><b>Tracking Days:</b></td>
		<td align="left"><input name="tracking_days" type="text" value="<? echo $tracking_days; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Short List - Number Of Referrers To Display:</b></td>
		<td align="left"><input name="short_num_referrers" type="text" value="<? echo $short_num_referrers; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Short List - Number Of Columns To Display:</b></td>
		<td align="left"><input name="short_num_columns" type="text" value="<? echo $short_num_columns; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Short List Alignment - Column 1:</b></td>
		<td align="left">
		  <select name="short_align_1">
		  	<option <? if ($short_align_1 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($short_align_1 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($short_align_1 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($short_align_1 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Short List Alignment - Column 2:</b></td>
		<td align="left">
		  <select name="short_align_2">
		  	<option <? if ($short_align_2 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($short_align_2 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($short_align_2 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($short_align_2 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Short List Alignment - Column 3:</b></td>
		<td align="left">
		  <select name="short_align_3">
		  	<option <? if ($short_align_3 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($short_align_3 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($short_align_3 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($short_align_3 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Short List Alignment - Column 4:</b></td>
		<td align="left">
		  <select name="short_align_4">
		  	<option <? if ($short_align_4 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($short_align_4 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($short_align_4 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($short_align_4 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Short List Alignment - Column 5:</b></td>
		<td align="left">
		  <select name="short_align_5">
		  	<option <? if ($short_align_5 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($short_align_5 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($short_align_5 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($short_align_5 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>		
	<tr>
		<td align="right"><b>Short List CSS Table Style:</b><br></td>
		<td align="left"><input name="short_css" type="text" value="<? echo $short_css; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Random List - Number Of Referrers To Display:</b></td>
		<td align="left"><input name="random_num_referrers" type="text" value="<? echo $random_num_referrers; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Random List - Number Of Columns To Display:</b></td>
		<td align="left"><input name="random_num_columns" type="text" value="<? echo $random_num_columns; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Random List Alignment - Column 1:</b></td>
		<td align="left">
		  <select name="random_align_1">
		  	<option <? if ($random_align_1 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($random_align_1 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($random_align_1 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($random_align_1 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Random List Alignment - Column 2:</b></td>
		<td align="left">
		  <select name="random_align_2">
		  	<option <? if ($random_align_2 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($random_align_2 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($random_align_2 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($random_align_2 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Random List Alignment - Column 3:</b></td>
		<td align="left">
		  <select name="random_align_3">
		  	<option <? if ($random_align_3 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($random_align_3 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($random_align_3 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($random_align_3 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Random List Alignment - Column 4:</b></td>
		<td align="left">
		  <select name="random_align_4">
		  	<option <? if ($random_align_4 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($random_align_4 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($random_align_4 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($random_align_4 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Random List Alignment - Column 5:</b></td>
		<td align="left">
		  <select name="random_align_5">
		  	<option <? if ($random_align_5 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($random_align_5 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($random_align_5 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($random_align_5 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>		
	<tr>
		<td align="right"><b>Random List CSS Table Style:</b><br></td>
		<td align="left"><input name="random_css" type="text" value="<? echo $random_css; ?>" size="50"></td>
	</tr>		
	<tr>
		<td align="right"><b>Full List - Number Of Referrers Per Page:</b></td>
		<td align="left"><input name="full_per_page" type="text" value="<? echo $full_per_page; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Full List - Number of Columns To Display:</b></td>
		<td align="left"><input name="full_num_columns" type="text" value="<? echo $full_num_columns; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Full List Alignment - Column 1:</b></td>
		<td align="left">
		  <select name="full_align_1">
		  	<option <? if ($full_align_1 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($full_align_1 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($full_align_1 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($full_align_1 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Full List Alignment - Column 2:</b></td>
		<td align="left">
		  <select name="full_align_2">
		  	<option <? if ($full_align_2 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($full_align_2 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($full_align_2 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($full_align_2 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Full List Alignment - Column 3:</b></td>
		<td align="left">
		  <select name="full_align_3">
		  	<option <? if ($full_align_3 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($full_align_3 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($full_align_3 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($full_align_3 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Full List Alignment - Column 4:</b></td>
		<td align="left">
		  <select name="full_align_4">
		  	<option <? if ($full_align_4 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($full_align_4 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($full_align_4 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($full_align_4 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>
	<tr>
		<td align="right"><b>Full List Alignment - Column 5:</b></td>
		<td align="left">
		  <select name="full_align_5">
		  	<option <? if ($full_align_5 == "LEFT") { echo "selected"; } ?> value="LEFT">LEFT</option>
			<option <? if ($full_align_5 == "RIGHT") { echo "selected"; } ?> value="RIGHT">RIGHT</option>
			<option <? if ($full_align_5 == "CENTER") { echo "selected"; } ?> value="CENTER">CENTER</option>
			<option <? if ($full_align_5 == "JUSTIFY") { echo "selected"; } ?> value="JUSTIFY">JUSTIFY</option>
		  </select>
		</td>
	</tr>					
	<tr>
		<td align="right"><b>Full List CSS Table Style:</b><br></td>
		<td align="left"><input name="full_css" type="text" value="<? echo $full_css; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Maximum Length:</b></td>
		<td align="left"><input name="max_length" type="text" value="<? echo $max_length; ?>" size="50"></td>
	</tr>
	<tr>
		<td align="right"><b>Minimum Hits:</b></td>
		<td align="left"><input name="min_hits" type="text" value="<? echo $min_hits; ?>" size="50"></td>
	</tr>
	<tr>
		<td colspan="2"><div align="right" class="style5"><input name="Save" type="submit" id="Save" value="Save"></div></td>
	</tr>
  </table>
</form>
<?
	include($full_path.'admin/footer.php');
?>
