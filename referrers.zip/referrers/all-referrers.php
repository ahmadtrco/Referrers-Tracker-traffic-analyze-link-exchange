<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */
 
include('./config.php');
include($full_path.'functions.php');

$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
@mysql_select_db($tgdbName, $tgdb);

$config = getConfig();

?>
<?

// Ban
if ($_REQUEST["action"] == "ban" && strlen($_REQUEST["url"]) > 2)
{
	$current_datetime = date("Y-m-d H:i:s");
	$delete_hits_result = mysql_query("delete from tg_ref_hits where url like '%".$_REQUEST["url"]."%'");
	$delete_approved_result = mysql_query("delete from tg_ref_approved where url like '%".$_REQUEST["url"]."%'");
	$ban_check = mysql_query("select 'X' from tg_ref_banned where ban_text = '".$_REQUEST["url"]."'");
	if (mysql_num_rows($ban_check) == 0) 
	{
		$ban_result = mysql_query("insert into tg_ref_banned (ban_text, ban_date) values ('".$_REQUEST["url"]."', '".$current_datetime."')");
	}
}

// Edit
if ($_REQUEST["action"] == "edit")
{
	$update_result = mysql_query("update tg_ref_approved set alias = '".$_REQUEST["alias"]."', forward = '".$_REQUEST["forward"]."' where url = '".$_REQUEST["url"]."'");
}	

// Save Settings
if ($_REQUEST["action"] == "savesettings")
{
	$update_result = mysql_query("update tg_ref_config set tracking_days = '".$_REQUEST["tracking_days"]."', short_num_referrers = '".$_REQUEST["short_num_referrers"]."', short_num_columns = '".$_REQUEST["short_num_columns"]."', short_align_1 = '".$_REQUEST["short_align_1"]."', short_align_2 = '".$_REQUEST["short_align_2"]."', short_align_3 = '".$_REQUEST["short_align_3"]."', short_align_4 = '".$_REQUEST["short_align_4"]."', short_align_5 = '".$_REQUEST["short_align_5"]."', short_css = '".$_REQUEST["short_css"]."', random_num_referrers = '".$_REQUEST["random_num_referrers"]."', random_num_columns = '".$_REQUEST["random_num_columns"]."', random_align_1 = '".$_REQUEST["random_align_1"]."', random_align_2 = '".$_REQUEST["random_align_2"]."', random_align_3 = '".$_REQUEST["random_align_3"]."', random_align_4 = '".$_REQUEST["random_align_4"]."', random_align_5 = '".$_REQUEST["random_align_5"]."', random_css = '".$_REQUEST["random_css"]."', full_per_page = '".$_REQUEST["full_per_page"]."', full_num_columns = '".$_REQUEST["full_num_columns"]."', full_align_1 = '".$_REQUEST["full_align_1"]."', full_align_2 = '".$_REQUEST["full_align_2"]."', full_align_3 = '".$_REQUEST["full_align_3"]."', full_align_4 = '".$_REQUEST["full_align_4"]."', full_align_5 = '".$_REQUEST["full_align_5"]."', full_css = '".$_REQUEST["full_css"]."', max_length = '".$_REQUEST["max_length"]."', min_hits = '".$_REQUEST["min_hits"]."', auto_approve = '".$_REQUEST["auto_approve"]."' where config_id = 1");
}

cleanDb($config['tracking_days']);
generateTextFile($config);
?>

  <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td><b>Top Referrers Sites </b>
</td>
      <td>
      <b>Hits </b>
      </td>
          </tr>
<?
$ref_result = mysql_query("select max(hit_id) as hit_id, url as url, full_url, sum(hits_out) as hits_out, count(*) as hits_in from tg_ref_hits group by url having hits_in >= ".$config['min_hits']." order by hits_in desc");
$count = 1;
while ($ref_row = mysql_fetch_array($ref_result))
{
	$short_url = str_replace("www.", "", $ref_row['url']);
	$approved_result = mysql_query("select * from tg_ref_approved where url = '".$ref_row['url']."'");
	
	if (mysql_num_rows($approved_result) > 0) 
	{
		$approved_row = mysql_fetch_array($approved_result);
		$alias = $approved_row['alias'];
		$forward = $approved_row['forward'];
	
		if ($count & 1)
		{
//			echo "<tr bgcolor=''>";
		}
		else
		{
//			echo "<tr bgcolor=''>";
		}	
		?>
		<tr>
<td>

<a href="<? echo $short_path; ?>click.php?id=<? echo $ref_row['hit_id']; ?>" title="http://<? echo $ref_row['url']; ?>" target="_blank">
		<?
		if ($alias == "")
		{
			echo $short_url;    
		}
		else
		{
			echo $alias;
		}
		?></a>
		<?
		if ($forward != "") 
		{
			?>

			<?
		}
		?>		
		
		</td>
		<td>
		<? echo $ref_row['hits_in'];?>
		</td>
	    </tr>
		<?
		$count++;
	}		
}
?>
    </table>
<br> 
<table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td><b>Referrers Sites</b></td>
      <td><b>Hits</b></td>
          </tr>
<?
if (mysql_num_rows($ref_result) > 0) 
{
	mysql_data_seek($ref_result, 0);
}
$count = 1;
while ($ref_row = mysql_fetch_array($ref_result))
{
	$short_url = str_replace("www.", "", $ref_row['url']);
	$approved_result = mysql_query("select * from tg_ref_approved where url = '".$ref_row['url']."'");

	if (mysql_num_rows($approved_result) == 0) 
	{
$alias = "";
		$forward = "";
	
		if ($count & 1)
		{
		}
		else
		{
		}	
		?>
		<tr>
		<td>
		<img src="/referrers/admin/images/star.gif" width="16" height="16" border="0">
		<a href="<? echo $short_path; ?>click.php?id=<? echo $ref_row['hit_id']; ?>" title="http://<? echo $ref_row['url'];?>" target="_blank"><? echo $short_url; ?></a>
		</td>
		<td>
		<? echo $ref_row['hits_in'];?>
		
		</td>	    	    
	    </tr>
	    
		<?
		$count++;
	}		
}
?>

  </table>
<br>

<?

?>