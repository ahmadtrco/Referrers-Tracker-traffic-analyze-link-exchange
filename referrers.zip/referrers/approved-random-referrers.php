<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

include_once('config.php');
include_once($full_path.'functions.php');

$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
@mysql_select_db($tgdbName, $tgdb);

$config = getConfig();

?>
<table width="100%" class="<? echo $config['random_css']; ?>">
<?

$cur_result = mysql_query("select * from tg_ref_cur");
$cur_num_rows = mysql_num_rows($cur_result);

if ($cur_num_rows >= $config['random_num_referrers'])
{
	$cur_count = 1;
	$col_count = 1;
	
	$randomNumbers = array();
	for ($i=0;$i<$config['random_num_referrers'];$i++) 
	{
   		$random = mt_rand(0,$cur_num_rows-1);
   		while(in_array($random,$randomNumbers)) 
		{
       		$random = mt_rand(0,$cur_num_rows-1);
		}
   		array_push($randomNumbers,$random);
		
		mysql_data_seek($cur_result, $random);
		$random_row = mysql_fetch_row($cur_result);
   		
		if ($col_count == 1)
		{	
			?>
			<tr class="<? echo $config['random_css']; ?>">
			<?
		}
		
		if ($col_count == 1)
		{
			?>
			<td align="<? echo $config['random_align_1']; ?>" class="<? echo $config['random_css']; ?>">
			<?
		}
		else if ($col_count == 2)
		{
			?>
			<td align="<? echo $config['random_align_2']; ?>" class="<? echo $config['random_css']; ?>">
			<?
		}
		else if ($col_count == 3)
		{
			?>
			<td align="<? echo $config['random_align_3']; ?>" class="<? echo $config['random_css']; ?>">
			<?
		}
		else if ($col_count == 4)
		{
			?>
			<td align="<? echo $config['random_align_4']; ?>" class="<? echo $config['random_css']; ?>">
			<?
		}
		else if ($col_count == 5)
		{
			?>
			<td align="<? echo $config['random_align_5']; ?>" class="<? echo $config['random_css']; ?>">
			<?
		}		
		
		?>
		<a href="<? echo $short_path; ?>click.php?id=<? echo $random_row[1]; ?>" target="_blank" title="IN: <? echo $random_row[3]; ?> / OUT: <? echo $random_row[4]; ?>"><? echo $random_row[2]; ?></a></td>
		<?
		if ($col_count == $config['random_num_columns'])
		{
			?></tr><?
			$col_count = 1;
		}
		else
		{
			$col_count++;
		}	
	
		$cur_count++;
	}	    
}
?>
</table>
