<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

include_once('config.php');
include_once($full_path.'functions.php');

$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
@mysql_select_db($tgdbName, $tgdb);

$config = getConfig();

cleanDb($config['tracking_days']);

generateTextFile($config);

	?>
	<table width="100%" class="<? echo $config['full_css']; ?>">
	<?

$delete_result = mysql_query("delete from tg_ref_cur");
$opt_result = mysql_query("optimize table tg_ref_cur");

$ref_result = mysql_query("select max(hit_id) as hit_id, hits.url as url, sum(hits_out) as hits_out, count(*) as hits_in, app.alias as alias, app.forward as forward from tg_ref_hits hits, tg_ref_approved app where hits.url = app.url group by url having hits_in >= ".$config['min_hits']." order by hits_in desc LIMIT ".$config['full_per_page']);
$cur_count = 1;
$col_count = 1;
while ($ref_row = mysql_fetch_array($ref_result))
{
	$short_url = str_replace("www.", "", $ref_row['url']);
	$alias = $ref_row['alias'];
	$forward = $ref_row['forward'];
	
	if ($col_count == 1)
	{	
		?>
		<tr class="<? echo $config['css']; ?>">
		<?
	}
	
	if ($col_count == 1)
	{
		?>
		<td align="<? echo $config['full_align_1']; ?>" class="<? echo $config['css']; ?>">
		<?
	}
	else if ($col_count == 2)
	{
		?>
		<td align="<? echo $config['full_align_2']; ?>" class="<? echo $config['css']; ?>">
		<?
	}
	else if ($col_count == 3)
	{
		?>
		<td align="<? echo $config['full_align_3']; ?>" class="<? echo $config['css']; ?>">
		<?
	}
	else if ($col_count == 4)
	{
		?>
		<td align="<? echo $config['full_align_4']; ?>" class="<? echo $config['css']; ?>">
		<?
	}
	else if ($col_count == 5)
	{
		?>
		<td align="<? echo $config['full_align_5']; ?>" class="<? echo $config['css']; ?>">
		<?
	}		
	
	?>
	<a onmouseover="status=&#39;http://<? echo $ref_row['url']; ?>&#39;;return true" onmouseout="status=&#39;&#39;;return true" href="<? echo $short_path; ?>click.php?id=<? echo $ref_row['hit_id']; ?>" target="_blank" title="IN: <? echo $ref_row['hits_in']; ?> / OUT: <? echo $ref_row['hits_out']; ?>"><? 
	if ($alias == "")
	{
		$link_text = $short_url;
	}
	else
	{	
		$link_text = $alias;
	}
	echo $link_text;
	?></a></td>
	<?
	if ($col_count == $config['full_num_columns'])
	{
		?></tr><?
		$col_count = 1;
	}
	else
	{
		$col_count++;
	}	
	
	// Insert Current List
	$insert_result = mysql_query("insert into tg_ref_cur (id, click_id, link_text, hits_in, hits_out) values ('".$cur_count."', '".$ref_row['hit_id']."', '".$link_text."', '".$ref_row['hits_in']."', '".$ref_row['hits_out']."')");
	$cur_count++;
}
?>
</table>
<center>
<? 
	if ($adult == "YES")
	{
		?><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img alt="free referrers php scripts" src="<?php print $short_path; ?>images/hazratsultanbahu-icon.png" width="20" height="20" border="0"></a><?
	}
    else
	{
		?><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img alt="free referrers php scripts" src="<?php print $short_path; ?>images/hazratsultanbahu-icon.png" width="20" height="20" border="0"></a><?
	}
?>
</center>
