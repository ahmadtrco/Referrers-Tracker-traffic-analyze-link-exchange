<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

if(isset($_REQUEST["id"]) || isset($_REQUEST["site"]))
{
	include('config.php');
	include($full_path.'functions.php');
	
	$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
	@mysql_select_db($tgdbName, $tgdb);
		
	if(preg_match('!^[0-9]+$!', $_REQUEST["id"]))
	{
		$click_result = mysql_query("select hit_id, url from tg_ref_hits where hit_id='".$_REQUEST["id"]."'");
	}
	elseif(!empty($_REQUEST["site"]))
	{
		$url = addslashes($_REQUEST["site"]);
		$click_result = mysql_query("select hit_id, url from tg_ref_hits where url='$url' order by hit_id desc limit 1");
	}
	else
	{
		$click_result = null;
	}

	$click = mysql_fetch_object($click_result);
	if(is_object($click))
	{
		mysql_query("update tg_ref_hits set hits_out = hits_out+1 where hit_id = '".$click->hit_id."'");
		$url = stripslashes($click->url);

		$forward_result = mysql_query("select forward from tg_ref_approved where url = '$url'");
		$forward_row = mysql_fetch_array($forward_result);
		if ($forward_row['forward'] != "")
		{
			$url = $forward_row['forward'];
		}
	}
	else
	{
		if (isset($_REQUEST["site"])) 
		{
			$url = $_REQUEST["site"];    
		}
		else
		{
			$url = &$_SERVER['SERVER_NAME'];
		}
	}
}
else
{
	$url = &$_SERVER['SERVER_NAME'];
}

header("Location: http://$url");
exit;
?>