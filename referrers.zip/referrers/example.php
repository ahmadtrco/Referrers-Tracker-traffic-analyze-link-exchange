<?php
include ($_SERVER['DOCUMENT_ROOT'] . '/referrers/log.php');
?><br>First Free Web Which Provide All and Every Thing about Hazrat Sultan Bahu �<br><iframe src="/referrers/referrers.html" frameborder="0" height="300" width="300"></iframe><br><object width="100%" height="100%" type="text/plain" data="/referrers/referrers.html" border="0" ></object>