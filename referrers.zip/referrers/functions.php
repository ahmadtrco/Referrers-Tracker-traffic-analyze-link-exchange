<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */
 
 // fixing line

function doLogout($logout)
{
	if ($logout==1)
	{
		setcookie ("UserName", "", time() - 3600);
		setcookie ("PassWord", "", time() - 3600);  
		header( 'refresh: 1; url=index.php' );
		echo '<h1>LOGGED OUT</h1>';
		exit;
	}
}

function userLogged()
{
	include($_SERVER['DOCUMENT_ROOT'] . '/referrers/config.php');
	global $_COOKIE;
	
    $Entered_UserName = "";
    $Entered_PassWord = "";

    if(isset($_COOKIE["UserName"]) &&
       isset($_COOKIE["PassWord"]))
      {
      $Entered_UserName = $_COOKIE["UserName"];
      $Entered_PassWord = $_COOKIE["PassWord"];
      }                    
       
    if(trim($Entered_UserName) != $adminName || $Entered_PassWord != $adminPass)
      {
      //$LogInPage should be the name of an existing file
      //with alternative web content. If you don't wish to
      //provide such content, just pass the empty string.
      include($full_path.'admin/login.php');
      return(false);
      }
    else
      return(true);
}

function getConfig()
{
	include($_SERVER['DOCUMENT_ROOT'] . '/referrers/config.php');
	$config_result = mysql_query("select * from tg_ref_config");
	$config = mysql_fetch_array($config_result);
	return($config);
}

function cleanDb($tracking_days)
{
	$seconds=time()-(86400*$tracking_days);   
	mysql_query("delete from tg_ref_hits where hit_time < $seconds");   
	if(mysql_affected_rows())
	{
		mysql_query("optimize table tg_ref_hits");
	}
}

function generateTextFile($config)
{
	include($_SERVER['DOCUMENT_ROOT'] . '/referrers/config.php');
	$file_text = '<table width="100%" class="'.$config['short_css'].'">';
	$ref_result = mysql_query("select max(hit_id) as hit_id, hits.url as url, sum(hits_out) as hits_out, count(*) as hits_in, app.alias as alias, app.forward as forward from tg_ref_hits hits, tg_ref_approved app where hits.url = app.url group by url having hits_in >= ".$config['min_hits']." order by hits_in desc LIMIT ".$config['short_num_referrers']);

	$col_count = 1;
	while ($ref_row = mysql_fetch_array($ref_result))
	{
		$short_url = str_replace("www.", "", $ref_row['url']);
		$alias = $ref_row['alias'];
		$forward = $ref_row['forward'];
		
		if ($col_count == 1)
		{		
			$file_text .= '<tr class="'.$config['css'].'">';
		}
		
		if ($col_count == 1)
		{
			$file_text .= '<td align='.$config['short_align_1'].' class="'.$config['css'].'">';
		}
		else if ($col_count == 2)
		{
			$file_text .= '<td align='.$config['short_align_2'].' class="'.$config['css'].'">';
		}
		else if ($col_count == 3)
		{
			$file_text .= '<td align='.$config['short_align_3'].' class="'.$config['css'].'">';
		}
		else if ($col_count == 4)
		{
			$file_text .= '<td align='.$config['short_align_4'].' class="'.$config['css'].'">';
		}
		else if ($col_count == 5)
		{
			$file_text .= '<td align='.$config['short_align_5'].' class="'.$config['css'].'">';
		}						
		
		$file_text .= '<a onmouseover="status=&#39;http://'.$ref_row['url'].'&#39;;return true" onmouseout="status=&#39;&#39;;return true" href="'.$short_path.'click.php?id='.$ref_row['hit_id'].'" target="_blank" title="IN: '.$ref_row['hits_in'].' / OUT: '.$ref_row['hits_out'].'">';
		if ($alias == "")
		{
			$file_text .= $short_url;    
		}
		else
		{
			$file_text .= $alias;
		}
		$file_text .= '</a></td>';
		
		if ($col_count == $config['short_num_columns'])
		{
			$file_text .= '</tr>';
			$col_count = 1;
		}
		else
		{
			$col_count++;
		}
	}
	
	$file_text .= '</table>';
	
	chmod($full_path."referrers.txt",0666);
	
	if(is_writable($full_path.'referrers.txt'))
	{
		$file = fopen($full_path.'referrers.txt','w');
		fwrite($file, $file_text);
		fclose($file);
	}
	else
	{
		echo "Unable to save <b>".$short_path."referrers.txt</b>: Permission denied.";
	}
	
	chmod($full_path."referrers.txt",0644);		
	copy($full_path."referrers.txt", $full_path."referrers.html");
}	
?>