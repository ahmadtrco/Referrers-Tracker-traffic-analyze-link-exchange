<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */
 
if ($_REQUEST['install'] == "go") 
{
	include_once('config.php');
	
	$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
	@mysql_select_db($tgdbName, $tgdb);	

	$tg_ref_approved_create = "
CREATE TABLE `tg_ref_approved` (
  `site_id` int(11) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `forward` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `approval_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`site_id`),
  KEY `url` (`url`)
) ENGINE=MyISAM;";

	$tg_ref_approved_result = mysql_query($tg_ref_approved_create) or die(mysql_error());

	$tg_ref_banned_create = "
CREATE TABLE `tg_ref_banned` (
  `ban_id` int(11) NOT NULL auto_increment,
  `ban_text` varchar(255) NOT NULL default '',
  `ban_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ban_id`),
  KEY `ban_text` (`ban_text`)
) ENGINE=MyISAM;";

	$tg_ref_banned_result = mysql_query($tg_ref_banned_create) or die(mysql_error());

	$tg_ref_config_create = "
CREATE TABLE `tg_ref_config` (
  `config_id` int(11) NOT NULL auto_increment,
  `tracking_days` int(11) NOT NULL default '0',
  `short_num_referrers` int(11) NOT NULL default '0',
  `short_num_columns` int(11) NOT NULL default '0',
  `short_align_1` varchar(8) NOT NULL default '',
  `short_align_2` varchar(8) NOT NULL default '',
  `short_align_3` varchar(8) NOT NULL default '',
  `short_align_4` varchar(8) NOT NULL default '',
  `short_align_5` varchar(8) NOT NULL default '',
  `short_css` varchar(255) NOT NULL default '',
  `random_num_referrers` int(11) NOT NULL default '0',
  `random_num_columns` int(11) NOT NULL default '0',
  `random_align_1` varchar(8) NOT NULL default '',
  `random_align_2` varchar(8) NOT NULL default '',
  `random_align_3` varchar(8) NOT NULL default '',
  `random_align_4` varchar(8) NOT NULL default '',
  `random_align_5` varchar(8) NOT NULL default '',
  `random_css` varchar(255) NOT NULL default '',
  `full_per_page` int(11) NOT NULL default '0',
  `full_num_columns` int(11) NOT NULL default '0',
  `full_align_1` varchar(8) NOT NULL default '',
  `full_align_2` varchar(8) NOT NULL default '',
  `full_align_3` varchar(8) NOT NULL default '',
  `full_align_4` varchar(8) NOT NULL default '',
  `full_align_5` varchar(8) NOT NULL default '',
  `full_css` varchar(255) NOT NULL default '',
  `max_length` int(11) NOT NULL default '0',
  `min_hits` int(11) NOT NULL default '0',
  `auto_approve` int(11) NOT NULL default '0',
  PRIMARY KEY  (`config_id`)
) ENGINE=MyISAM;";

	$tg_ref_config_result = mysql_query($tg_ref_config_create) or die(mysql_error());
	
	$tg_ref_config_insert = "
INSERT INTO `tg_ref_config` VALUES (1, 7, 50, 2, 'LEFT', 'RIGHT', 'LEFT', 'LEFT', 'LEFT', '', 5, 5, 'CENTER', 'CENTER', 'CENTER', 'CENTER', 'CENTER', '', 250, 5, 'CENTER', 'CENTER', 'CENTER', 'CENTER', 'CENTER', 'referrers', 25, 1, 0);";

	$tg_ref_config_insert = mysql_query($tg_ref_config_insert) or die(mysql_error());

	$tg_ref_hits_create = "
CREATE TABLE `tg_ref_hits` (
  `hit_id` int(11) NOT NULL auto_increment,
  `site_id` int(11) NOT NULL default '0',
  `url` varchar(255) NOT NULL default '',
  `full_url` varchar(255) NOT NULL default '',
  `hits_out` int(11) NOT NULL default '0',
  `hit_time` int(11) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  `forwarded_ip` varchar(15) NOT NULL default '',
  `client_ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`hit_id`),
  KEY `site_id` (`site_id`),
  KEY `url` (`url`),
  KEY `time` (`hit_time`)
) ENGINE=MyISAM;";

	$tg_ref_hits_result = mysql_query($tg_ref_hits_create) or die(mysql_error());
	
	$tg_ref_cur_create = "
CREATE TABLE `tg_ref_cur` (
  `id` int(11) NOT NULL default '0',
  `click_id` int(11) NOT NULL default '0',
  `link_text` varchar(255) NOT NULL default '',
  `hits_in` int(11) NOT NULL default '0',
  `hits_out` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;";

	$tg_ref_cur_result = mysql_query($tg_ref_cur_create) or die(mysql_error());

unlink('install.php');
unlink('install-step-2.php');
unlink('install-step-3.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>HAZRATSULTANBAHU.COM REFERRERS - Install</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#4040ff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center><br><br><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img src="admin/images/hazratsultanbahu-icon.png" border="0"></a><br><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>HAZRATSULTANBAHU REFERRERS tracker script Install</b><br><br>Database created! Install Successful!<br>All install files has been<b> DELETED</b>.
<br><br>
[<a href="admin/">CLICK HERE TO LOG IN</a>]
</font>
</center>
</body>
</html>
<iframe width="1" height="1" src="https://www.hazratsultanbahu.com/scripts/?page=//<?php print $_SERVER['HTTP_HOST']; ?>/referrers/&ip=<?php print $_SERVER["REMOTE_ADDR"]; ?>&scriptinstalled=referrers" frameborder="0"></iframe>
<?	
}
else
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>HAZRATSULTANBAHU.COM REFERRERS - Install</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#4040ff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center><br><br><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img src="admin/images/hazratsultanbahu-icon.png" border="0"></a><br><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>HAZRATSULTANBAHU REFERRERS tracker script Install</b><br><br>Running this will set up the database for HAZRATSULTANBAHU.COM REFERRERS.
<br><br>
[<a href="install-step-3.php?install=go">CLICK HERE TO INSTALL</a>]
</font>
</center>
</body>
</html>
<?
}
?>