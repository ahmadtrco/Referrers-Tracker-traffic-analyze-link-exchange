<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */
 
 // step 1 checking whether file exists or not

$text = dirname(__FILE__);

if (stripos($text, "public_html/referrers") !== false) { } else {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>HAZRATSULTANBAHU REFERRERS - Install Step 1</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#4040ff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center><br><br><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img src="admin/images/hazratsultanbahu-icon.png" border="0"></a><br><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>
HAZRATSULTANBAHU REFERRERS script Install</b><br><br>Please make sure That your 
current install directory is referrers <br> and this directory must need to be 
in your web main root directory of public_html<br>Please create referrers folder in 
public_html folder and<br>put all files in referrers folder then install script<br> <b>
Current folder is not referrers and or<br>referrers folder is not in public_html web folder</b>
<br><br>Please fix and then install<br>

</font>
</center>
</body>
</html>
<?
exit;
  }
 
// step 2 checking whether file exists or not
$file_pointer = 'config.php';
 
if (file_exists($file_pointer)) 
{

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>HAZRATSULTANBAHU REFERRERS - Install Step 1</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#4040ff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center><br><br><a href="https://www.hazratsultanbahu.com/scripts/" target="_blank"><img src="admin/images/hazratsultanbahu-icon.png" border="0"></a><br><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>HAZRATSULTANBAHU REFERRERS script Install</b><br><br> Please first <b>DELETE</b> config.php file<br>from current folder to install script.
<br>then install<br>

</font>
</center>
</body>
</html>
<?	
}
else
{
print "<script>";
print " self.location='install-step-2.php';";
print "</script>";
exit;
}
?>