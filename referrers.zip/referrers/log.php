<?php
/**
 *
 * HAZRATSULTANBAHU.COM REFERRERS tracker Script
 * Copyright 2018 (c) HAZRATSULTANBAHU
 * https://www.hazratsultanbahu.com/scripts/
 * Version 1.1
 *
 * This file is part of HAZRATSULTANBAHU.COM REFERRERS php scripts.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is free software; you can redistribute it
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software HAZRATSULTANBAHU.COM; either version 1 of the License, or any later version.
 *  
 *  HAZRATSULTANBAHU.COM REFERRERS tracker Script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with HAZRATSULTANBAHU.COM REFERRERS tracker Script; if not, write to the Free Software
 *  Thokhar Naiz Baig, Lahore 53700. Pakistan
 */

if(basename($_SERVER['SCRIPT_NAME'])=='log.php')
{
	exit;
}

$full_url = strtolower($_SERVER['HTTP_REFERER']);

include_once $_SERVER['DOCUMENT_ROOT'] . '/referrers/config.php';
include($full_path.'/functions.php');

$tgdb = @mysql_connect($tgdbHost, $tgdbUser, $tgdbPass) or die(mysql_error());
@mysql_select_db($tgdbName, $tgdb);

$config = getConfig();

$block = str_replace(".","\.",$site_url);
$b_count = "1";
$ban_result = mysql_query("select ban_text from tg_ref_banned");

while ($ban_row = mysql_fetch_array($ban_result))
{
 	$block = $block."|";   
	$block .= str_replace(".","\.",$ban_row['ban_text']);
	$b_count++;
}

if($_SERVER['REQUEST_METHOD']=='HEAD'||$_SERVER['REQUEST_METHOD']=='PUT')
{
	exit;
}

if(!empty($_SERVER['HTTP_REFERER'])&&!preg_match("!$block!i",$full_url))
{

	preg_match('!^https?://([a-zA-Z\-_\.0-9]+)!',addslashes(htmlspecialchars($full_url,ENT_QUOTES)),$ref);
	$ref=$ref[1];

	if(!empty($ref))
	{
		$parts=explode('.',$ref);
		$size=count($parts);

		if($size==2||$size==3&&$parts[1]=='co'&&strlen($parts[2])==2)
		{
			$ref='www.'.join('.',$parts);	
		}
		elseif($parts[0]!='www'&&$subdomain_sub) // elseif($subdomain_sub)
		{
			preg_match('!\.([a-zA-Z\-_0-9]+\.[a-zA-Z]+(\.[a-zA-Z]{2})?)$!',$ref,$new);
			
			if(substr_count($subdomain_sub,$new[1]))
				$ref='www.'.$new[1];
		}

		$forwarded_ip = addslashes(trim($_SERVER['HTTP_X_FORWARDED_FOR']));
		$client_ip = addslashes(trim($_SERVER['HTTP_CLIENT_IP']));
		
		$ref = strtolower($ref);

		if(!is_banned())
		{
			mysql_query("insert into tg_ref_hits (url, full_url, hits_out, hit_time, ip, forwarded_ip, client_ip) values ('$ref','$full_url',0,'".time()."','{$_SERVER['REMOTE_ADDR']}','$forwarded_ip','$client_ip')");
		}
	}
}

function is_banned()
{
	global $ref,$ban_time,$forwarded_ip,$client_ip;
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	if ($forwarded_ip == "")
	{
		$check_forwarded_ip = $ip;    
	}
	else
	{
		$check_forwarded_ip = $forwarded_ip;
	}
	
	if ($client_ip == "")
	{
		$check_client_ip = $ip;    
	}
	else
	{
		$check_client_ip = $client_ip;
	}

	$ban_query = mysql_query("select hit_time from tg_ref_hits where (ip = '$ip' || forwarded_ip = '$check_forwarded_ip' || client_ip = '$check_client_ip') and url='$ref' order by hit_id desc limit 1"); 
    $ban_result = mysql_fetch_object($ban_query);
	
    if(is_object($ban_result))
    {
        if($ban_result->hit_time > time()-(1800))
            return true;
    }
	
    return false;
}
mysql_close($tgdb);
?>